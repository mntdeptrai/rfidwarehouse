@echo off
title UHF Hardware Bridge Service (RFIDReaderAPI.dll)
cd /d "%~dp0"
echo =========================================================
echo    STARTING UHF HARDWARE BRIDGE FOR FLUTTER DESKTOP
echo    Loading Native Drivers: RFIDReaderAPI.dll, Basic.dll
echo =========================================================
UHFHardwareBridge.exe
pause
